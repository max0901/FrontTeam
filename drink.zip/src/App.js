import './App.css';
import CommonStyles from './Styled/style';
import Routing from './Routes/routing';

function App() {
  return (
    <div>
      <CommonStyles />
      <Routing />
    </div>
  );
}

export default App;
