import { createGlobalStyle } from "styled-components";

const GlobalStyles = createGlobalStyle`
* {
    box-sizing: border-box;
    margin: 0;
    padding: 0;
    list-style: none;
  }
  
body {
  background-color: rgb(250, 235, 215);
  font-family: arial, helvetica;
}

body::-webkit-scrollbar {
  display: none;
}

h1,h2,h3,h4,h5 {
  margin: 0;
  padding: 0;
}

`;
export default GlobalStyles;
