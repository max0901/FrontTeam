import styled from "styled-components";

export const Section = styled.section`
  height: 50vh;
  /* display: flex; */
  justify-content: center;
  align-items: center;
`;
export const Img1 = styled.img`
  width: 100%;
  height: 100vh;
  z-index: -1;
  display: block;
  margin: auto;
`;
// export const Img2 = styled.img`
//     width: 100%;
//     position: absolute;
//     z-index:1;
//     top:89%;
//     /* right: -2% */

// `
export const Img2 = styled.img`
  width: 100%;
  height: 100vh;
  z-index: -1;
  display: block;
  margin: auto;
`;
// export const Img4 = styled.img`
//     width: 100%;
//     position: absolute;
//     z-index:1;
//     top:187%;
//     /* right: -2% */

// `
export const Img3 = styled.img`
  width: 100%;
  height: 100vh;
  z-index: -1;
  display: block;
  margin: auto;
`;
// export const Img6 = styled.img`
//     width: 100%;
//     position: absolute;
//     z-index:1;
//     top:240.7%;
//     max-width: 100%;
// `
export const Img4 = styled.img`
  width: 50%;
  height: 100vh;
  z-index: -1;
  display: block;
  float: left;
`;
// export const Img8 = styled.img`
//     width: 100%;
//     position: absolute;
//     z-index:1;
//     top:388%;
// `
export const Img5 = styled.img`
  width: 50%;
  height: 100vh;
  z-index: -1;
  display: block;
  margin: auto;
`;
export const Img6 = styled.img`
  width: 100%;
  height: 100vh;
  z-index: -1;
  display: block;
  margin: auto;
`;
export const BtnDot = styled.div`
  position: fixed;
  /* background-color: black; */
  right: 2%;
  top: 40%;
  & div {
    margin-top: 10px;
  }
  & .active span {
    background-color: black;
    visibility: visible;
    opacity: 1;
    transition: all 1s ease;
  }
`;

export const Dot = styled.span`
  cursor: pointer;
  height: 15px;
  width: 15px;
  margin: 0 2px;
  background-color: #bbb;
  border-radius: 50%;
  display: inline-block;
  transition: all 0.6s ease;
`;
