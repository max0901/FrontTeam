import React from "react";

import * as Styled from "./style";
import { FullPage, Slide } from "react-full-page/lib";
import { useEffect } from "react";
import { useState } from "react";
import { useCallback } from "react";
import { Link } from "react-scroll";
const MainBody2 = () => {
  const [scroll, setScroll] = useState(true);

  //스크롤 Y축 50이상시 nav창 활성화
  const handlerScroll = useCallback(() => {
    if (window.scrollY >= 50) {
      // target.current.style.top = "-100px";
      setScroll(false);
    } else {
      // console.log(scroll);
      setScroll(true);
    }
  }, [scroll]);

  //스크롤 감지 로직
  useEffect(() => {
    window.addEventListener("scroll", handlerScroll);
    // console.log(scroll);

    return () => {
      window.removeEventListener("scroll", handlerScroll);
    };
  }, [scroll, handlerScroll]);

  return (
    <>
      {scroll ? (
        <div></div>
      ) : (
        <Styled.BtnDot>
          <ul>
            <li>
              <Link to={1} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
            <li>
              <Link to={2} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
            <li>
              <Link to={3} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
            <li>
              <Link to={4} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
          </ul>
        </Styled.BtnDot>
      )}
      <FullPage>
        <Slide id={1}>
          <Styled.Img1 src="../img/BackImg3.png" alt="" />
        </Slide>
        <Slide id={2}>
          <Styled.Img2 src="../img/BackImg6.png" alt="" />
        </Slide>
        <Slide id={3}>
          <Styled.Img2 src="../img/BackImg6.png" alt="" />
        </Slide>
      </FullPage>
    </>
  );
};
export default MainBody2;
