import React, { useCallback } from "react";
import { useRef } from "react";
import { useEffect } from "react";
import { useState } from "react";
import * as Styled from "./style";
import { Link } from "react-scroll";
const MainBody = () => {
  const [scroll, setScroll] = useState(true);

  //스크롤 Y축 50이상시 nav창 활성화
  const handlerScroll = useCallback(() => {
    if (window.scrollY >= 50) {
      // target.current.style.top = "-100px";
      setScroll(false);
    } else {
      // console.log(scroll);
      setScroll(true);
    }
  }, [scroll]);

  //스크롤 감지 로직
  useEffect(() => {
    window.addEventListener("scroll", handlerScroll);
    // console.log(scroll);

    return () => {
      window.removeEventListener("scroll", handlerScroll);
    };
  }, [scroll, handlerScroll]);

  return (
    <>
      {scroll ? (
        <div></div>
      ) : (
        <Styled.BtnDot>
          <ul>
            <li>
              <Link to={1} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
            <li>
              <Link to={2} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
            <li>
              <Link to={3} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
            <li>
              <Link to={4} spy={true} smooth={true}>
                <Styled.Dot></Styled.Dot>
              </Link>
            </li>
          </ul>
        </Styled.BtnDot>
      )}
      <div>
        <Styled.Section>
          <div>
            <Styled.Img1 src="../img/BackImg3.png" alt="" id={1} />
          </div>
          <div>
            <Styled.Img2 src="../img/BackImg6.png" alt="" id={2} />
          </div>
          <div>
            <Styled.Img3 src="../img/BackImg7.jpg" alt="" id={3} />
          </div>
          <div>
            <Styled.Img4 src="../img/BackImg19.jpg" alt="" id={4} />
          </div>
          <div>
            <Styled.Img5 src="../img/BackImg9.png" alt="" />
          </div>
          <div>
            <Styled.Img6 src="../img/BackImg20.jpg" alt="" />
          </div>
        </Styled.Section>
        <dot></dot>
      </div>
    </>
  );
};

export default MainBody;
