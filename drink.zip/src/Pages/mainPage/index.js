import React from "react";
import Layout from "../../Layout/layout";
import MainBody2 from "./main/main2";
import MainBody from "./main/main";

const MainPage = () => {
  return (
    <Layout>
      {/* <MainBody /> */}
      <MainBody2 />
    </Layout>
  );
};

export default MainPage;
