import styled from "styled-components";

export const Section = styled.div`
    display: flex;
`
export const Img13 = styled.img`
    width: 40%;
    height: 80vh;
    display: inline;
    margin-top: 110px;
    margin-left: 50px;
`
export const Info = styled.div`
    margin-top: 300px;
    margin-left: 80px;
    & h1{
        /* line-height: 70px; */
        text-align: center;
    }
    & h3{
        text-align: center;
    }
    & p{
        text-align: center;
        line-height: 50px;
    }
`