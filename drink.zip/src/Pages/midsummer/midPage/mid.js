import React from 'react';
import * as Styled from "./style";

const MidSummer = () => {
    return (
        <div>
            <Styled.Section>
                <Styled.Img13 src="../img/MIDSUMMER.jpg" alt="" />
                <Styled.Info>
                    <h1>핸드릭스 미드서머 솔스티스 진</h1>
                    <p>Limited Edition</p>
                    <h3>일년 중 '하지'에 가장 강렬한 향을 뿜어내며 생생하게 살아나는 <br />자연의 영원한 수수께끼에 영감을 받아 만든 진<br />
                        핸드릭스 고유의 기분 좋은 청량감은 유지하되 강렬한 꽃의 아로마를 가미하여 <br />허브와 꽃의 향이 증폭된 플로럴 진 </h3>
                    <p>43.4% ABV, 700ml</p>
                </Styled.Info>
            </Styled.Section>
        </div>
    )
}

export default MidSummer;