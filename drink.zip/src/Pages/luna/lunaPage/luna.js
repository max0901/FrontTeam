import React from 'react';
import * as Styled from "./style";


const Luna = () => {
    return (
        <div>
            <Styled.Section>
                <Styled.Img11 src="../img/LUNA.png" alt="" />
                <Styled.Info>
                    <h1>핸드릭스 루나 진</h1>
                    <p>Limited Release</p>
                    <h3>기존 핸드릭스 진의 장미와 오이의 풍미는 그대로 살린 가운데<br />입안 가득한 꽃 향기와 함께 은은하게 퍼지는 감귤류 시트러스 피니시가<br />조화를 이루는 유쾌하고 매혹적인 진</h3>
                    <p>43.4% ABV, 750ml</p>
                </Styled.Info>
            </Styled.Section>
        </div>
    )
}

export default Luna;