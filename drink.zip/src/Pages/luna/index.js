import React from 'react';
import Layout from '../../Layout/layout';
import Luna from './lunaPage/luna';


const LunaPage = () => {
    return (
        <Layout>
            <Luna />
        </Layout>
    )
}

export default LunaPage;