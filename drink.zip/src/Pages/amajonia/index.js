import React from 'react';
import Layout from '../../Layout/layout';
import Amajonia from './amaPage/ama';

const AmaPage = () => {
    return (
        <Layout>
            <Amajonia />
        </Layout>
    )
}

export default AmaPage;