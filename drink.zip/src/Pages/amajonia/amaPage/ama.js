import React from 'react';
import * as Styled from "./style";

const Amajonia = () => {
    return (
        <div>
            <Styled.Section>
                <Styled.Img12 src="../img/Amajonia.png" alt="" />
                <Styled.Info>
                    <h1>핸드릭스 아마조니아 진</h1>
                    <p>Limited Release</p>
                    <h3>기존의 헨드릭스의 오이와 장미의 진한 기운에 밝고 열대적인 아마존이 더해져 완성된 특별한 진<br />
                        신선한 오이향에 열대과일의 향이 더해져 파인애플처럼 달면서 특유 풀내음이<br /> 나며 시원한 주니퍼로 기존의 헨드릭스와는 다른 피니쉬를 보여줍니다.</h3>
                    <p>43.4% ABV, 1L</p>
                </Styled.Info>
            </Styled.Section>
        </div>
    )
}

export default Amajonia;