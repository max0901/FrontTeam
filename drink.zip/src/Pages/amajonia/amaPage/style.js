import styled from "styled-components";

export const Section = styled.div`
    display: flex; 
`
export const Img12 = styled.img`
    width: 50%;
    height: 100vh;
    display: inline;
`
export const Info = styled.div`
     margin-top: 270px;
    margin-right: 70px;
    & h1{
        text-align: center;
    }
    & h3{
        text-align: center;
    }
    & p{
        text-align: center;
        line-height: 40px;
    }
`