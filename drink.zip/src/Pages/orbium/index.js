import React from 'react';
import Layout from '../../Layout/layout';
import Orbium from './orbPage/orbium';

const OrbPage = () => {
    return (
        <Layout>
            <Orbium />
        </Layout>
    )
}

export default OrbPage;