import React from 'react';
import * as Styled from "./style";

const Orbium = () => {
    return (
        <div>
            <Styled.Section>
                <Styled.Img15 src="../img/ORBIUM.png" alt="" />
                <Styled.Info>
                    <h1>핸드릭스 오비움 진</h1>
                    <p>Limited Release</p>
                    <h3>퀴닌, 쑥, 연꽃의 추가 추출물로 재창조된 핸드릭스 진<br />
                        놀라운 달콤함과 강한 여운에서 꽃향기까지 나선형으로 이어지는 독특한 여운을<br /> 결합하여 전혀 예상치 못한 고혹적인 클라이맥스로 이동시켜준다.</h3>
                    <p>43.4% ABV, 700ml</p>
                </Styled.Info>
            </Styled.Section>
        </div>
    )
}

export default Orbium;