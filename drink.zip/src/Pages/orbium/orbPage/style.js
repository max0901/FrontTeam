import styled from "styled-components";

export const Section = styled.div`
    display: flex;
`
export const Img15 = styled.img`
    width: 50%;
    height: 100vh;
    display: inline;
`
export const Info = styled.div`
    margin-top: 270px;
    margin-right: 66px;
    & h1{
        /* line-height: 70px; */
        text-align: center;
    }
    & h3{
        text-align: center;
    }
    & p{
        text-align: center;
        line-height: 50px;
    }
`