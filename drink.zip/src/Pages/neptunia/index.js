import React from 'react';
import Layout from '../../Layout/layout';
import Neptunia from './nepPage/nep';

const NepPage = () => {
    return (
        <Layout>
            <Neptunia />
        </Layout>
    )
}

export default NepPage;