import React from 'react';
import * as Styled from "./style";

const Neptunia = () => {
    return (
        <div>
            <Styled.Section>
                <Styled.Img14 src="../img/NEPTUNIA.png" alt="" />
                <Styled.Info>
                    <h1>핸드릭스 넵튜니아 진</h1>
                    <p>Limited Release</p>
                    <h3>헨드릭스의 마스터 '디스틸러 레슬리 그레이시'가 해안선을 따라 거닐 때<br />들었던 파도가 전해주는 시적인 선율에 염감을 받아 탄생한 진<br />
                        스코틀랜드 연안에서 자라는 해안식물과 입안 가득 바닷바람을 연상하게 하는<br /> 신선하고 부드러운 시트러스의 완벽한 밸런스로 스코틀랜드 해안가에서 불어오는 먼 바닷바람의 느낌을 그대로 전달해준다.</h3>
                    <p>43.4% ABV, 700mL</p>
                </Styled.Info>
            </Styled.Section>
        </div>
    )
}

export default Neptunia;