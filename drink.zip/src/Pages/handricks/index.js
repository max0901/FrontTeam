import React from 'react'
import Layout from '../../Layout/layout'
import Handricks from './handPage/hand'

const HandPage = () => {
    return (
        <Layout>
            <Handricks />
        </Layout>
    )
}

export default HandPage;