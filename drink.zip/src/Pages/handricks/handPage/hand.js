import React from 'react';
import * as Styled from "./style";

const Handricks = () => {
    return (
        <div>
            <Styled.Section>
                <Styled.Img10 src="../img/HANDRICKS.png" alt="" />
                <Styled.Info>
                    <h1>핸드릭스 진</h1>
                    <h3>핸드릭스 진은 11가지의 고급식물<br />(카모마일, 엘더플라워, 주니퍼, 레몬 껍질, 오렌지 껍질, 캐러웨이,<br /> 고수, 큐브베리, 안젤리카 뿌리, 야로우 뿌리, 오리스 뿌리)<br />이 결합되고 오이와 장미의 기이하고 놀라운 인퓨전으로 만든 특이한 진입니다.</h3>
                    <p>44% ABV, 700ml</p>
                </Styled.Info>
            </Styled.Section>
        </div>
    )
}

export default Handricks;