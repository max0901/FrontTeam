import styled from "styled-components";

export const Section = styled.div`
    display: flex;
`
export const Img10 = styled.img`
    width: 50%;
    height: 100vh;
    display: inline;
`
export const Info = styled.div`
    margin-top: 300px;
    & h1{
        line-height: 70px;
        text-align: center;
    }
    & h3{
        text-align: center;
    }
    & p{
        text-align: center;
        line-height: 40px;
    }
`