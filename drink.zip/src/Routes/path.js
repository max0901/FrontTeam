import HandPage from "../Pages/handricks";
import MainPage from "../Pages/mainPage";
import LunaPage from "../Pages/luna";
import AmaPage from "../Pages/amajonia";
import NepPage from "../Pages/neptunia";
import MidPage from "../Pages/midsummer";
import OrbPage from "../Pages/orbium";


const routes = () => [
    {
        path: "/",
        element: <MainPage />,
    },
    {
        path: "/handricks",
        element: <HandPage />,
    },
    {
        path: "/luna",
        element: <LunaPage />,
    },
    {
        path: "/amajonia",
        element: <AmaPage />,
    },
    {
        path: "/neptunia",
        element: <NepPage />,
    },
    {
        path: "/midsummer",
        element: <MidPage />,
    },
    {
        path: "/orbium",
        element: <OrbPage />,
    },
];
export default routes;
