import styled from "styled-components";
// import { Link } from "react-router-dom";

export const Header = styled.div`
    width: 100%;
`
export const Title = styled.div`
    margin-left: 150px;
    position: fixed;
    z-index: 2;
    left: -70px;
    & button {
        position: absolute;
        left: 600px;
        top: 20px;
        background-color:transparent;
        border: 0;
        outline: 0;
        /* display: none; */
        z-index: 3;
        margin: 0;
        padding: 0;
        margin-left: 1100px;
}
    & button label {
    width: 30px;
    height: 20px;
    display: block;
    position: relative;
    cursor: pointer;
}
    & button label span {
    display: block;
    height: 2px;
    background-color: #000;
    background-color: rgba(0, 0, 0, 1);
    opacity: 3;
    left: 0;
    width: 100%;
    position: absolute;
    transition: 0.3s;
    z-index: 1000; 
    
}
    & label span:nth-child(1) {
        top:0;
}
    & label span:nth-child(2) {
        top:50%;
}
    & label span:nth-child(3) {
        top:100%;
}
    /* & .buttom:checked + label span:nth-child(1) {
        top: 50%;
        transform: rotate(45deg);
}
    & buttom:checked + label span:nth-child(2) {
        opacity: 0;
}
    & .buttom:checked + label span:nth-child(3) {
        top: 50%;
        transform: rotate(-45deg);
} */
`
export const ImgLogo = styled.img`
    position: relative;
    top: 15px;
`
export const Menu = styled.ul`
    width: 22%;
    height: 100vh;
    position: fixed;
    /* background-color: #E6E6E6; */
    background-color: #ffffff;
    background-color: rgba( 255, 255, 255, 0.5 );
    z-index: 4;
    right:0px ;
    opacity: 3;
    visibility: hidden;
    /* transition: all 1s ease; */
    transition: 0.3s;
    & nav{
        display: block;
        align-items: center;
        margin-top: 80px;
    }
    & li{
        list-style: none;
        line-height: 80px;
    }
    & a{
        text-decoration: none;
        color: black;
        margin: 2em;
        font-size: 1.5em;
    }
    & button{
        position: relative;
        left: 80%;
        bottom: 550px;
    }
    /* & .sidebar {
    width: 250px;
    height: 100vh;
    background-color: pink;
    position: fixed;
    top: 0;
    left: 0;
    left: -250px;
    transition: 0.3s;
} */

/* check시 같이 밀려나가는 CSS 햄버거 메뉴 */
/* & buttom:checked + label[for=trigger] {
    left: 210px;
    transition: 0.3s;
} */
`