import React from 'react'
import * as Styled from "./style";
import { Link } from "react-router-dom";
// import { useState } from 'react';
import { useRef } from 'react';

const Header = () => {
    // const [isOpen, setIsOpen] = useState(false);
    // const toggleSide = () => {
    //     setIsOpen(true);
    // };
    const target = useRef(null);
    // const target2 = useRef(null)
    const ToggleSide = () => {
        // if (isOpen) {
        //     setIsOpen(false)
        // } else {

        //     setIsOpen(true)
        // }
        target.current.style.opacity = 1
        target.current.style.visibility = "visible"
        // target2.current.style.display = "none"

    }
    const CloseBtn = () => {
        target.current.style.opacity = 0
        target.current.style.visibility = "hidden"
        // target2.current.style.display = "block"
    }
    return (
        <div>
            <Styled.Header>
                <Styled.Title>
                    <Link to="/">
                        <Styled.ImgLogo src="../img/Logo.png" alt="핸드릭스" />
                    </Link>
                    <button onClick={ToggleSide}>
                        <label>
                            <span></span>
                            <span></span>
                            <span></span>
                        </label>
                    </button>
                    {/* <button onClick={CloseBtn} ref={target2}>
                        <label>
                            <span></span>
                            <span></span>
                            <span></span>
                        </label>
                    </button> */}
                </Styled.Title>
            </Styled.Header>
            <Styled.Menu ref={target}>
                <li><Link to="/handricks">핸드릭스</Link></li>
                <li><Link to="/neptunia">넵튜니아</Link></li>
                <li><Link to="/amajonia">아마조니아</Link></li>
                <li><Link to="/luna">루나</Link></li>
                <li><Link to="/orbium">오비움</Link></li>
                <li><Link to="/midsummer">미드서머 솔스티스</Link></li>
                <button onClick={CloseBtn}>버튼</button>
            </Styled.Menu>
        </div>
    )
};

export default Header;